# COVID19 Data Analysis Using Python

### Coursera Project

The course materials belong entirely to Coursera. Also, the COVID19 dataset, published by John Hopkins University. The answers are the only things that show my trials.

Course Objectives:
===================
Merge the two datasets to see if there is any relationship between the spread of the the virus in a country and how happy people are, living in that country.

Great thanks to the course instructor: Ahmad Varasteh
